from django.apps import AppConfig


class FourAppConfig(AppConfig):
    name = 'four_app'
