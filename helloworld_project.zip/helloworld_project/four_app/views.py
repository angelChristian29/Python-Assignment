from django.shortcuts import render
my_dict={'data':[10,11,12,13,14]}
# Create your views here.
def index(request):
	return render(request,"four_app/index.html",context=my_dict)
