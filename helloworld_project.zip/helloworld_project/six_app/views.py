from django.shortcuts import render

# Create your views here.
def page1(request):
	return render(request,"six_app/page1.html")

def page2(request):
	return render(request,"six_app/page2.html")