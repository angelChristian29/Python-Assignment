from django.apps import AppConfig


class SixAppConfig(AppConfig):
    name = 'six_app'
