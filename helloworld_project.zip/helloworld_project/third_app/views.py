from django.shortcuts import render

def index(request):
    user_name = "angel christian"
    return render(request, 'third_app/index.html', {'user_name': user_name})
