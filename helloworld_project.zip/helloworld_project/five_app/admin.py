from django.contrib import admin

# Register your models here.
from five_app.models import *

class EmployeeAdmin(admin.ModelAdmin):
	list_display=['id','name','age']
	
admin.site.register(Employee,EmployeeAdmin)