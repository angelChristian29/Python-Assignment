from django.shortcuts import render
from five_app.models import *

var=Employee.objects.all()
context={'list':var}
# Create your views here.
def index(request):
	return render(request,"five_app/index.html",context)