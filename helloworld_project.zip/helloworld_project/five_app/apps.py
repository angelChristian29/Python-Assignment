from django.apps import AppConfig


class FiveAppConfig(AppConfig):
    name = 'five_app'
