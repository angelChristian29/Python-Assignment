from django.shortcuts import render

# Create your views here.
my_dict1=[{'Name':'Angel','Age':'20','Stream':'Commerce'},{'Name':'priya','Age':'35','Stream':'Science'}]
var={'student':my_dict1}

def index(request):
	return render(request,"second_app/index.html",context=var);
